# utils/data_preprocessing.py
import pandas as pd
import numpy as np
from typing import Tuple

def preprocess_data(data: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocess the input data for model training/prediction
    """
    df = data.copy()
    
    # Handle missing values
    numerical_cols = ['Area', 'No. of Bedrooms', 'Floor_Number', 'Age']
    for col in numerical_cols:
        if col in df.columns:
            df[col].fillna(df[col].median(), inplace=True)
    
    # Handle outliers in Area using IQR
    if 'Area' in df.columns:
        q1 = df['Area'].quantile(0.25)
        q3 = df['Area'].quantile(0.75)
        iqr = q3 - q1
        upper_bound = q3 + 1.5 * iqr
        lower_bound = q1 - 1.5 * iqr
        df['Area'] = df['Area'].clip(lower_bound, upper_bound)
    
    return df
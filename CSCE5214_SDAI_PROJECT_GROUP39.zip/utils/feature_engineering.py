# utils/feature_engineering.py
import pandas as pd
import numpy as np

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create new features from existing ones
    """
    data = df.copy()
    
    # Price per square foot (if Price column exists)
    if 'Price' in data.columns and 'Area' in data.columns:
        data['price_per_sqft'] = data['Price'] / data['Area']
    
    # Age categories
    if 'Age' in data.columns:
        data['age_category'] = pd.cut(
            data['Age'],
            bins=[-np.inf, 2, 5, 10, 20, np.inf],
            labels=['New', 'Recent', 'Medium', 'Old', 'Very Old']
        )
    
    # Amenities score
    amenity_columns = ['Gymnasium', 'Car Parking', 'Indoor Games', 'Jogging Track']
    if all(col in data.columns for col in amenity_columns):
        data['amenities_score'] = data[amenity_columns].sum(axis=1)
    
    # Size category based on Area
    if 'Area' in data.columns:
        data['size_category'] = pd.qcut(
            data['Area'],
            q=5,
            labels=['Very Small', 'Small', 'Medium', 'Large', 'Very Large']
        )
    
    return data
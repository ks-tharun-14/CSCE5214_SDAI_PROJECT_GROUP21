import numpy as np
import pandas as pd
import joblib
from typing import Dict, Any

from models.random_forest_model import RandomForestModel
from models.decision_tree_model import DecisionTreeModel

class ModelManager:
    def __init__(self):
        self.models = {}
        self.label_encoders = {}
        self.scaler = None
        self.required_features = [
            'Location',
            'Area',
            'No. of Bedrooms',
            'Property_Type',
            'Floor_Number',
            'New/Resale',
            'Gymnasium',
            'Car Parking',
            'Indoor Games',
            'Jogging Track'
        ]

    def load_model(self, model_name: str, model_path: str) -> None:
        """Load a trained model from disk using the model's class method."""
        try:
            if model_name == 'random_forest':
                model_instance = RandomForestModel.load_model(model_path)
            elif model_name == 'decision_tree':
                model_instance = DecisionTreeModel.load_model(model_path)
            else:
                raise Exception(f"Unknown model name: {model_name}")

            self.models[model_name] = model_instance
            print(f"Successfully loaded model: {model_name}")
        except Exception as e:
            raise Exception(f"Error loading model {model_name}: {str(e)}")

    def load_preprocessing(self, preprocessing_path: str):
        try:
            prep_data = joblib.load(preprocessing_path)
            self.label_encoders = prep_data['label_encoders']
            self.scaler = prep_data['scaler']
        except Exception as e:
            raise Exception(f"Error loading preprocessing objects: {str(e)}")

    def preprocess_input(self, input_data: Dict[str, Any]) -> pd.DataFrame:
        df = pd.DataFrame([input_data])

        categorical_cols = ['Location', 'Property_Type']
        for col in categorical_cols:
            encoder = self.label_encoders.get(col)
            df[col] = df[col].map(lambda x: encoder.transform([x])[0] if x in encoder.classes_ else -1)

        boolean_fields = ['New/Resale', 'Gymnasium', 'Car Parking', 'Indoor Games', 'Jogging Track']
        for field in boolean_fields:
            df[field] = df[field].astype(int)

        numerical_features = ['Area', 'No. of Bedrooms', 'Floor_Number']
        df[numerical_features] = self.scaler.transform(df[numerical_features])

        return df[self.required_features]

    def predict(self, input_data: Dict[str, Any]) -> Dict[str, float]:
        predictions = {}
        try:
            processed_input = self.preprocess_input(input_data)

            for model_name, model in self.models.items():
                try:
                    pred = model.predict(processed_input)[0]
                    predictions[model_name] = float(pred)
                except Exception as e:
                    print(f"Error predicting with {model_name}: {str(e)}")
                    predictions[model_name] = None

            return predictions

        except Exception as e:
            print(f"Error in prediction process: {str(e)}")
            return {model_name: None for model_name in self.models}

    def get_feature_importance(self, model_name: str) -> Dict[str, float]:
        if model_name not in self.models:
            return {}
        model = self.models[model_name].model
        if hasattr(model, 'feature_importances_'):
            return dict(zip(self.required_features, model.feature_importances_))
        return {}

import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

class RandomForestModel:
    def __init__(self):
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=None,
            min_samples_split=2,
            min_samples_leaf=1,
            random_state=42
        )
        self.feature_names = None
        self.r2_score_ = None
        self.mse_ = None

    def train(self, X, y):
        """
        Train the model on already preprocessed data.
        y is expected to be the actual target values (not transformed yet).
        We'll do the log transform here for consistency.
        """
        print("Starting Random Forest training...")
        print("Input features:", X.columns.tolist())
        self.feature_names = X.columns.tolist()

        # Log transform the target
        y_log = np.log(y)

        self.model.fit(X, y_log)

        y_pred_log = self.model.predict(X)
        self.r2_score_ = r2_score(y_log, y_pred_log)
        self.mse_ = mean_squared_error(y_log, y_pred_log)

        print("Training completed:")
        print(f"R2 Score (log scale): {self.r2_score_:.4f}")
        print(f"MSE (log scale): {self.mse_:.4f}")

    def predict(self, X):
        """
        Predict on already preprocessed data, returning predictions in original scale.
        """
        predictions_log = self.model.predict(X)
        predictions = np.exp(predictions_log)
        return predictions

    def save_model(self, filepath):
        import joblib
        model_data = {
            'model': self.model,
            'feature_names': self.feature_names,
            'r2_score_': self.r2_score_,
            'mse_': self.mse_
        }
        joblib.dump(model_data, filepath)

    @classmethod
    def load_model(cls, filepath):
        import joblib
        model_instance = cls()
        model_data = joblib.load(filepath)
        model_instance.model = model_data['model']
        model_instance.feature_names = model_data['feature_names']
        model_instance.r2_score_ = model_data.get('r2_score_')
        model_instance.mse_ = model_data.get('mse_')
        return model_instance

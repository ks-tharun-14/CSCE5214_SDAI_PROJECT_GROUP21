import os
from pathlib import Path

# Base directory of the project
BASE_DIR = Path(__file__).resolve().parent.parent

# Model configurations
MODEL_CONFIG = {
    'random_forest': {
        'model_path': os.path.join(BASE_DIR, 'models', 'saved_models', 'random_forest.pkl'),
        'features': ['Area', 'Location', 'No. of Bedrooms', 'New/Resale', 
                    'Gymnasium', 'Car Parking', 'Indoor Games', 'Jogging Track',
                    'Property_Type', 'Floor_Number', 'Age']
    },
    'linear_regression': {
        'model_path': os.path.join(BASE_DIR, 'models', 'saved_models', 'linear_regression.pkl'),
        'features': ['Area', 'Location', 'No. of Bedrooms', 'New/Resale', 
                    'Gymnasium', 'Car Parking', 'Indoor Games', 'Jogging Track',
                    'Property_Type', 'Floor_Number', 'Age']
    }
}

# Property types
PROPERTY_TYPES = [
    'Apartment',
    'Villa',
    'Independent House',
    'Penthouse'
]

# Additional amenities
AMENITIES = {
    'basic': ['Gymnasium', 'Car Parking', 'Indoor Games', 'Jogging Track'],
    'advanced': ['Swimming Pool', "Children's Play Area", '24x7 Security', 'Clubhouse']
}

# Flask configuration
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-here'
    DEBUG = False
    TESTING = False

class DevelopmentConfig(Config):
    DEBUG = True

class ProductionConfig(Config):
    DEBUG = False

class TestingConfig(Config):
    TESTING = True

# Select configuration based on environment
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
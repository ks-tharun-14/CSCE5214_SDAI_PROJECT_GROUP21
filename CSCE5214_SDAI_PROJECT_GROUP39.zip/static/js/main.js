// static/js/main.js
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    $('[data-toggle="tooltip"]').tooltip();
    
    // Initialize saved predictions view
    document.getElementById('savedPredictions').addEventListener('click', function(e) {
        e.preventDefault();
        showSavedPredictions();
    });
    
    // Initialize comparison view
    document.getElementById('compareLink').addEventListener('click', function(e) {
        e.preventDefault();
        showComparisonView();
    });
});

function sendPredictionRequest() {
    const predictionDiv = document.getElementById('prediction');
    if (!predictionDiv) {
        console.error("Prediction div not found!");
        return;
    }

    // Show loading message
    predictionDiv.innerHTML = `
        <div class="text-center">
            <div class="spinner-border text-primary" role="status">
                <span class="sr-only">Loading...</span>
            </div>
            <p class="mt-2">Calculating prediction...</p>
        </div>
    `;

    // Get form data
    const form = document.getElementById('prediction-form');
    const formData = new FormData(form);

    // Add checkbox values
    const checkboxes = ['toggle', 'gym', 'car', 'ind', 'jog'];
    checkboxes.forEach(id => {
        const checkbox = document.getElementById(id);
        formData.set(id, checkbox.checked ? 'on' : 'off');
    });

    // Debugging form data
    for (let [key, value] of formData.entries()) {
        console.log(`${key}: ${value}`);
    }

    // Send request
    fetch('/predict', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        console.log("Received data:", data);
        if (data.success) {
            displayPredictionResults(data);
        } else {
            throw new Error(data.error || 'Prediction failed');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        predictionDiv.innerHTML = `
            <div class="alert alert-danger">
                Error getting prediction: ${error.message}
            </div>
        `;
    });
}

function formatPrice(price) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
    }).format(price);
}

function displayPredictionResults(data) {
    const predictionDiv = document.getElementById('prediction');
    console.log("Full response data:", data);

    let html = `
        <div class="card mt-4">
            <div class="card-body">
                <h3 class="card-title text-center">Predicted Price</h3>
                <div class="text-center mb-4">
                    <h4 class="text-primary">${formatPrice(data.average_prediction)}</h4>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <h5>Model Predictions:</h5>
                        <ul class="list-group">
    `;

    // Add individual model predictions
    Object.entries(data.predictions).forEach(([model, prediction]) => {
        if (prediction !== null) {
            html += `
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    ${model.replace('_', ' ').toUpperCase()}
                    <span class="badge bg-primary rounded-pill">${formatPrice(prediction)}</span>
                </li>
            `;
        }
    });

    html += `
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h5>Price Range:</h5>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Minimum
                                <span class="badge bg-secondary rounded-pill">${formatPrice(data.price_range.low)}</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Maximum
                                <span class="badge bg-secondary rounded-pill">${formatPrice(data.price_range.high)}</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Add a table for feature importance if available
    if (data.feature_importance) {
        html += `
            <div class="card mt-4">
                <div class="card-body">
                    <h5>Feature Importance</h5>
                    <table class="table table-striped mt-3">
                        <thead>
                            <tr>
                                <th>Feature</th>
                                <th>Importance</th>
                            </tr>
                        </thead>
                        <tbody>
        `;

        Object.entries(data.feature_importance).forEach(([feature, importance]) => {
            html += `
                <tr>
                    <td>${feature}</td>
                    <td>${importance.toFixed(4)}</td>
                </tr>
            `;
        });

        html += `
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    predictionDiv.innerHTML = html;
}



function drawFeatureImportanceChart(featureImportance) {
    console.log("Drawing chart with:", featureImportance);

    const canvas = document.getElementById('featureImportanceChart');
    if (!canvas) {
        console.error("Canvas element not found!");
        return;
    }

    const ctx = canvas.getContext('2d');
    const labels = Object.keys(featureImportance);
    const values = Object.values(featureImportance);

    if (window.featureImportanceChart && typeof window.featureImportanceChart.destroy === 'function') {
        window.featureImportanceChart.destroy();
    }

    window.featureImportanceChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Feature Importance',
                data: values,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            animation: false, // Disable animations for a static look
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Importance'
                    }
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Model Feature Importance'
                }
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
}



// Add event listener when the document is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Document loaded, setting up event listeners');
    
    const form = document.getElementById('prediction-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            sendPredictionRequest();
        });
    } else {
        console.error('Prediction form not found!');
    }
});

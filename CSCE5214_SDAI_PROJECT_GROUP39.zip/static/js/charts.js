// static/js/charts.js

// Function to create the prediction comparison chart
function createPredictionChart(data) {
    const ctx = document.getElementById('predictionsChart').getContext('2d');
    
    // Extract model names and their predictions
    const modelNames = Object.keys(data.predictions);
    const predictionValues = Object.values(data.predictions).map(val => val / 100000); // Convert to lakhs
    
    // Create gradient for bars
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, 'rgba(54, 162, 235, 0.8)');
    gradient.addColorStop(1, 'rgba(54, 162, 235, 0.2)');

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: modelNames.map(name => name.replace('_', ' ').toUpperCase()),
            datasets: [{
                label: 'Predicted Price (Lakhs)',
                data: predictionValues,
                backgroundColor: gradient,
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `₹${context.raw.toFixed(2)} Lakhs`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Price (Lakhs)'
                    }
                }
            }
        }
    });
}

// Function to create the feature importance chart
function createFeatureImportanceChart(data) {
    const ctx = document.getElementById('featureImportanceChart').getContext('2d');
    
    // Sort features by importance
    const features = Object.entries(data.feature_importance)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 8); // Show top 8 features
    
    new Chart(ctx, {
        type: 'horizontalBar',
        data: {
            labels: features.map(f => f[0].replace('_', ' ')),
            datasets: [{
                label: 'Feature Importance',
                data: features.map(f => f[1]),
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Importance Score'
                    }
                }
            }
        }
    });
}

// Function to create comparison chart for multiple properties
function createComparisonChart(properties) {
    const ctx = document.getElementById('comparisonChart').getContext('2d');
    
    // Prepare data for chart
    const labels = properties.map((prop, index) => `Property ${index + 1}`);
    const datasets = Object.keys(properties[0].predictions).map(model => ({
        label: model.replace('_', ' ').toUpperCase(),
        data: properties.map(prop => prop.predictions[model] / 100000), // Convert to lakhs
        backgroundColor: model.includes('random') ? 
            'rgba(54, 162, 235, 0.6)' : 'rgba(75, 192, 192, 0.6)',
        borderColor: model.includes('random') ? 
            'rgba(54, 162, 235, 1)' : 'rgba(75, 192, 192, 1)',
        borderWidth: 1
    }));

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ₹${context.raw.toFixed(2)} Lakhs`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Price (Lakhs)'
                    }
                }
            }
        }
    });
}

// Function to update charts when new data is available
function updateCharts(data) {
    // Clear existing charts
    const chartsContainer = document.querySelector('.charts-container');
    chartsContainer.innerHTML = `
        <div class="chart-wrapper">
            <canvas id="predictionsChart"></canvas>
        </div>
        <div class="chart-wrapper">
            <canvas id="featureImportanceChart"></canvas>
        </div>
    `;
    
    // Create new charts
    createPredictionChart(data);
    if (data.feature_importance) {
        createFeatureImportanceChart(data);
    }
}

// Export functions for use in other files
window.chartFunctions = {
    createPredictionChart,
    createFeatureImportanceChart,
    createComparisonChart,
    updateCharts
};
// static/js/comparison.js
function showComparisonView() {
    const savedPredictions = getSavedPredictions();
    const mainContainer = document.querySelector('.container');
    
    let html = `
        <div class="comparison-container">
            ${savedPredictions.map(prediction => createComparisonCard(prediction)).join('')}
        </div>
    `;
    
    mainContainer.innerHTML = html;
}

function createComparisonCard(prediction) {
    return `
        <div class="card property-card">
            <div class="card-body">
                <h5 class="card-title">Property Details</h5>
                <p>Location: ${prediction.property.Location}</p>
                <p>Area: ${prediction.property.Area} sq ft</p>
                <p>Bedrooms: ${prediction.property['No. of Bedrooms']}</p>
                <h6 class="mt-3">Predictions</h6>
                <p class="lead">₹${formatCurrency(prediction.average_prediction)}</p>
            </div>
        </div>
    `;
}
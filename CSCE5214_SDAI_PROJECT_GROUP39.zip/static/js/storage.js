// static/js/storage.js
function savePrediction(data) {
    let savedPredictions = JSON.parse(localStorage.getItem('savedPredictions') || '[]');
    savedPredictions.push(data);
    if (savedPredictions.length > 5) savedPredictions.shift(); // Keep only last 5
    localStorage.setItem('savedPredictions', JSON.stringify(savedPredictions));
}

function getSavedPredictions() {
    return JSON.parse(localStorage.getItem('savedPredictions') || '[]');
}
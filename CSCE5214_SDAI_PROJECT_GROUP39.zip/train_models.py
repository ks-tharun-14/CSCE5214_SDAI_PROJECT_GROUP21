import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
import joblib
import os

from models.random_forest_model import RandomForestModel
from models.decision_tree_model import DecisionTreeModel

def prepare_data():
    """Load and prepare the dataset"""
    print("Loading dataset...")
    data = pd.read_csv('train.csv')
    
    # Add Property Type and Floor Number if not in dataset
    if 'Property_Type' not in data.columns:
        data['Property_Type'] = 'Apartment'  # Default value
    if 'Floor_Number' not in data.columns:
        data['Floor_Number'] = 0  # Default value
    
    features = [
        'Location',
        'Area',
        'No. of Bedrooms',
        'Property_Type',
        'Floor_Number',
        'New/Resale',
        'Gymnasium',
        'Car Parking',
        'Indoor Games',
        'Jogging Track'
    ]

    X = data[features]
    y = data['Price']
    
    print("\nFeature info:")
    print(X.info())
    print("\nSample of first few rows:")
    print(X.head())
    return X, y

def main():
    # Create models directory if it doesn't exist
    if not os.path.exists('models/saved_models'):
        os.makedirs('models/saved_models')
    
    print("Loading and preparing data...")
    X, y = prepare_data()

    # We will preprocess once here
    categorical_features = ['Location', 'Property_Type']
    boolean_fields = ['New/Resale', 'Gymnasium', 'Car Parking', 'Indoor Games', 'Jogging Track']
    numerical_features = ['Area', 'No. of Bedrooms', 'Floor_Number']

    # Convert boolean fields to int
    for field in boolean_fields:
        X[field] = X[field].astype(int)

    # Fit label encoders for categorical fields
    label_encoders = {}
    for col in categorical_features:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col])
        label_encoders[col] = le

    # Fit scaler for numerical fields
    scaler = StandardScaler()
    X[numerical_features] = scaler.fit_transform(X[numerical_features])

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train Random Forest
    rf_model = RandomForestModel()
    rf_model.train(X_train, y_train)
    rf_model.save_model('models/saved_models/random_forest.pkl')
    print("Random Forest Model saved successfully!")

    # Train Decision Tree
    dt_model = DecisionTreeModel()
    dt_model.train(X_train, y_train)
    dt_model.save_model('models/saved_models/decision_tree.pkl')
    print("Decision Tree Model saved successfully!")

    # Save preprocessing objects
    prep_data = {
        'label_encoders': label_encoders,
        'scaler': scaler
    }
    joblib.dump(prep_data, 'models/saved_models/preprocessing.pkl')
    print("Preprocessing objects saved successfully!")

if __name__ == "__main__":
    main()

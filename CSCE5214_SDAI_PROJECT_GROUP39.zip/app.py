from flask import Flask, render_template, request, jsonify
from config.config import config, PROPERTY_TYPES, AMENITIES
from models.model_utils import ModelManager
import pandas as pd
import numpy as np
import os

app = Flask(__name__)
app.config.from_object(config['development'])

model_manager = ModelManager()

# Load training data for locations
data = pd.read_csv('train.csv')
locations = sorted(data['Location'].unique())

# Ensure models directory exists
os.makedirs('models/saved_models', exist_ok=True)

# Load all models
try:
    model_manager.load_model('random_forest', 'models/saved_models/random_forest.pkl')
    model_manager.load_model('decision_tree', 'models/saved_models/decision_tree.pkl')
    # Load preprocessing objects
    model_manager.load_preprocessing('models/saved_models/preprocessing.pkl')
except Exception as e:
    print(f"Error loading models: {str(e)}")
    print("Please ensure you have trained the models and saved the preprocessing objects.")

@app.route('/')
def index():
    """Render the main page with enhanced form options"""
    return render_template(
        'home.html',
        locations=locations,
        property_types=PROPERTY_TYPES,
        amenities=AMENITIES
    )

@app.route('/predict', methods=['POST'])
def predict():
    """Prediction endpoint"""
    try:
        input_data = {
            'Location': request.form.get('location'),
            'Area': float(request.form.get('area')),
            'No. of Bedrooms': int(request.form.get('bhk')),
            'Property_Type': request.form.get('property_type', 'Apartment'),
            'Floor_Number': int(request.form.get('floor_number', 0)),
            'New/Resale': request.form.get('toggle') == 'on',
            'Gymnasium': request.form.get('gym') == 'on',
            'Car Parking': request.form.get('car') == 'on',
            'Indoor Games': request.form.get('ind') == 'on',
            'Jogging Track': request.form.get('jog') == 'on'
        }
        
        predictions = model_manager.predict(input_data)
        valid_predictions = [p for p in predictions.values() if p is not None]

        if not valid_predictions:
            raise ValueError("No valid predictions obtained")

        avg_prediction = float(np.mean(valid_predictions))
        price_range = {
            'low': float(min(valid_predictions)),
            'high': float(max(valid_predictions))
        }

        response = {
            'success': True,
            'predictions': predictions,
            'average_prediction': avg_prediction,
            'price_range': price_range,
            'feature_importance': model_manager.get_feature_importance('random_forest')
        }
        print(response)

        return jsonify(response)

    except Exception as e:
        print(f"Error in prediction: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

# Add this route in app.py
@app.route('/compare')
def compare():
    return render_template('components/comparison_view.html')


if __name__ == "__main__":
    app.run(debug=True, port=5000)
